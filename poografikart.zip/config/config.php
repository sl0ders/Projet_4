<?php
return array(
    "db_user" => "root",
    "db_pass" =>"",
    "db_host" => "localhost",
    "db_name" => "Blog"
);