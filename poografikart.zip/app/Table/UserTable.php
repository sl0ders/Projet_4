<?php

namespace App\Table;
use App\Table\Table;
class UserTable extends Table
{

}