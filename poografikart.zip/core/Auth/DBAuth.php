<?php

namespace Core\Auth;

use Core\Database\MysqlDatabase;

class DBAuth
{
    private $db;

    public function __construct(MysqlDatabase $db)
    {
        $this->db = $db;

    }

    /**
     * @param $username
     * @param $password
     * @return boolean
     */
    public function login($username, $password)
    {
        $user = $this->db->prepare( 'SELECT * FROM users WHERE username = ?', [$username], null, true );
        if ($user) {
            return $user->password === sha1( $password );
        }
        return false;

    }

    public function logged()
    {
        return isset( $_SESSION['auth'] );
    }

}