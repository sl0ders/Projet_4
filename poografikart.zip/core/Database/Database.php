<?php

namespace Core\Database;

class Database
{

}