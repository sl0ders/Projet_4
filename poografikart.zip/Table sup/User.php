<?php
/**
 * Created by PhpStorm.
 * User: sl0de
 * Date: 29/03/2019
 * Time: 09:23
 */

namespace App\Table;


class User
{

}